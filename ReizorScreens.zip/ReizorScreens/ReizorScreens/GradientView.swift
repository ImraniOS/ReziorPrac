//
//  GradientView.swift
//  ReizorScreens
//
//  Created by Coder Crew on 22/11/2023.
//

import UIKit

class GradientView: UIView {
 
    lazy var gradientLayer: CAGradientLayer = {
        let gradientLayer = CAGradientLayer()
        gradientLayer.frame = self.gradientLayer.bounds
        gradientLayer.colors = [UIColor.yellow.cgColor, UIColor.white.cgColor]
        return gradientLayer
    }()

    
    
}


