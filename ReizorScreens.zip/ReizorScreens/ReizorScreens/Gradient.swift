//
//  Gradient.swift
//  ReizorScreens
//
//  Created by Coder Crew on 23/11/2023.
//

import Foundation
import UIKit


class Gradient {
   
    static let shared = Gradient()
  
    func setUpGradientBtn(btn: UIButton){
        let gradientLayer2 = CAGradientLayer()
        
            gradientLayer2.colors = [UIColor(red: 0.93, green: 0.09, blue: 0.53, alpha: 1.0).cgColor, UIColor(red: 0.16, green: 0.33, blue: 0.78, alpha: 1.0).cgColor]
        gradientLayer2.frame = btn.bounds
        
        gradientLayer2.startPoint = CGPoint(x: 0, y: 0.5)
        gradientLayer2.endPoint = CGPoint(x: 1, y: 0.5)
        gradientLayer2.cornerRadius = 10
        btn.layer.insertSublayer(gradientLayer2, at: 0)
        
        
    }
   
    func setUpGradientView(view: UIView) {
        let gradientLayer2 = CAGradientLayer()
        
            gradientLayer2.colors = [UIColor(red: 0.93, green: 0.09, blue: 0.53, alpha: 1.0).cgColor, UIColor(red: 0.16, green: 0.33, blue: 0.78, alpha: 1.0).cgColor]
        gradientLayer2.frame = view.bounds
        
        gradientLayer2.startPoint = CGPoint(x: 0, y: 0.5)
        gradientLayer2.endPoint = CGPoint(x: 1, y: 0.5)
        gradientLayer2.cornerRadius = 6
        view.layer.insertSublayer(gradientLayer2, at: 0)
        
        
    }
    
    
    
    
    
    func removeGradient(btn : UIButton){
        if let sublayers = btn.layer.sublayers {
          for (index, layer) in sublayers.enumerated() {
            if layer is CAGradientLayer {
              layer.removeFromSuperlayer()
            }
          }
        }
      }
    
    
    
}
