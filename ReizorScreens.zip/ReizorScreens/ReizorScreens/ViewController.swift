//
//  ViewController.swift
//  ReizorScreens
//
//  Created by Coder Crew on 22/11/2023.
//

//Step 1 - Create a new gradient layer. ...
//Step 2 - Set the colors and locations for the gradient layer − ...
//Step 3 - Set the start and end points for the gradient layer. ...
//Step 4 - Set the frame to the layer.


import UIKit
class ViewController: UIViewController {
    
    @IBOutlet weak var tableViewHeight: NSLayoutConstraint!
    @IBOutlet weak var horiStack: UIStackView!
    @IBOutlet weak var settingBtn: UIButton!
    @IBOutlet weak var ntfsBtn: UIButton!
    @IBOutlet weak var merchandiseBtn: UIButton!
    @IBOutlet weak var tableView: UITableView!
    
    
    var photoData = ["m2","m2"]
    var nameData = ["Ablum2023","Ablum2024"]
    var desData = ["Group Cat taceower: Secret lineap Lorem ipsum dolor sit amet...","Group Cat taceower: Secret lineap Lorem ipsum dolor sit amet..."]
    var tablePhoto = ["my","Mask0","m2","Mask4","Mask3","Mask2"]
    var tableText = ["Group Cat taceower: Secret lineap Lorem ipsum dolor sit amet...","Group Cat taceower: Secret lineap Lorem ipsum dolor sit amet...","Group Cat taceower: Secret lineap Lorem ipsum dolor sit amet...","Group Cat taceower: Secret lineap Lorem ipsum dolor sit amet...","Group Cat taceower: Secret lineap Lorem ipsum dolor sit amet...","Group Cat taceower: Secret lineap Lorem ipsum dolor sit amet..."]
    var pauseData = ["Group 159","Group 159","Group 159","Group 159","Group 159","Group 159"]
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        //        let st = "\(tableView) * \(tableText) = \(tableView * tableText)"
        //        let result = tableView * tableText
        //        print(result)
        //        tableViewHeight
        
        //        tableView.rowHeight = UITableView.automaticDimension
        //        tableView.estimatedRowHeight = 100 // Provide an estimated row height for better performance
//        tableView.frame = CGRect(x: tableView.frame.origin.x, y: tableView.frame.origin.y, width: tableView.frame.size.width, height: tableView.contentSize.height)
        
        
//        Gradient.shared.setUpGradientBtn(btn:settingBtn, show: true)
//        Gradient.shared.setUpGradientBtn(btn:ntfsBtn,show: true)
        
        
    }
    
//    @IBAction func songsClicked(_ sender: UIButton) {
//        sender.isSelected = !sender.isSelected
//
////        Gradient.shared.setUpGradientBtn(btn:settingBtn )
//        Gradient.shared.setUpGradientBtn(btn:settingBtn,show: false)
//        Gradient.shared.setUpGradientBtn(btn:ntfsBtn,show: false)
//        Gradient.shared.setUpGradientBtn(btn:merchandiseBtn,show: false)
//        Gradient.shared.removeGradient(btn: merchandiseBtn)
//        Gradient.shared.removeGradient(btn: ntfsBtn)
//
//    }
    
   
    
//    @IBAction func ntfsClicked(_ sender: UIButton) {
//        sender.isSelected = !sender.isSelected
//
////        if(sender.isSelected == true)
////        {
////            settingBtn.isHidden = true
////            merchandiseBtn.isHidden = true
////        }   else
////        {
////            settingBtn.isHidden = false
////            merchandiseBtn.isHidden = false
////
////        }
//    }
    
    
//    @IBAction func merchandise(_ sender: UIButton) {
//        sender.isSelected = !sender.isSelected
//
////        if(sender.isSelected == true)
////        {
////            ntfsBtn.isHidden = true
////            settingBtn.isHidden = true
////        }   else
////        {
////            ntfsBtn.isHidden = false
////            settingBtn.isHidden = false
////
////        }
//    }
    
    
}
extension ViewController: UICollectionViewDataSource,UICollectionViewDelegateFlowLayout {
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return photoData.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "collectionCell", for: indexPath) as! CollectionViewCell
        cell.photoView.image = UIImage(named: photoData[indexPath.row])
        cell.nameLabel.text = nameData[indexPath.row]
        cell.descripLabel.text = desData[indexPath.row]
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        return CGSize(width: collectionView.bounds.width, height: collectionView.bounds.height)
    }
}
   
extension ViewController: UITableViewDataSource,UITableViewDelegate {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        //tableViewHeight.constant = CGFloat(tablePhoto.count * 95)
        return tablePhoto.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        
            let cell = tableView.dequeueReusableCell(withIdentifier: "tableCell", for: indexPath) as! TableViewCell
            cell.photoView.image = UIImage(named: tablePhoto[indexPath.row])
            cell.pausePhoto.image = UIImage(named: pauseData[indexPath.row])
            cell.desLabel.text = tableText[indexPath.row]
            return cell
        
       
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        
//        tableView.isScrollEnabled = (tableView.contentSize.height <= CGRectGetHeight(tableView.frame))
//        if (tableView.contentSize.height  <= tableView.frame.size.height) {
//                 tableView.isScrollEnabled = false;
//              }
//             else {
//                 tableView.isScrollEnabled = true;
//              }
//        return UITableView.automaticDimension
        return 90
        
    }
    
}
    
    

