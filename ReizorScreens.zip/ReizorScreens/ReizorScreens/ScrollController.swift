//
//  ScrollController.swift
//  Pods
//
//  Created by Coder Crew on 24/11/2023.
//

import UIKit

class ScrollController: UIViewController {
    
    @IBOutlet weak var songBtn: UIButton!
    
    @IBOutlet weak var tableHeight: NSLayoutConstraint!
    
    
    @IBOutlet weak var tableViewH: NSLayoutConstraint!
    
    
    
    var photoData = ["m2","m2"]
    var nameData = ["Ablum2023","Ablum2024"]
    var desData = ["Group Cat taceower: Secret lineap Lorem ipsum dolor sit amet...","Group Cat taceower: Secret lineap Lorem ipsum dolor sit amet..."]
    var tablePhoto = ["my","Mask0","m2","Mask4","Mask3","Mask2","Mask3","Mask2"]
    var tableText = ["Group Cat taceower: Secret lineap Lorem ipsum dolor sit amet...","Group Cat taceower: Secret lineap Lorem ipsum dolor sit amet...","Group Cat taceower: Secret lineap Lorem ipsum dolor sit amet...","Group Cat taceower: Secret lineap Lorem ipsum dolor sit amet...","Group Cat taceower: Secret lineap Lorem ipsum dolor sit amet...","Group Cat taceower: Secret lineap Lorem ipsum dolor sit amet...","Group Cat taceower: Secret lineap Lorem ipsum dolor sit amet...","Group Cat taceower: Secret lineap Lorem ipsum dolor sit amet..."]
    var pauseData = ["Group 159","Group 159","Group 159","Group 159","Group 159","Group 159","Group 159","Group 159"]
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
//        Gradient.shared.setUpGradientBtn(btn: songBtn, show: true)

    }
    
    
    @IBAction func songClicked(_ sender: UIButton) {
    }
    
}

extension ScrollController: UICollectionViewDataSource,UICollectionViewDelegateFlowLayout {
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return photoData.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "collectionCell", for: indexPath) as! CollectionViewCell
//        cell.photoView.image = UIImage(named: photoData[indexPath.row])
//        cell.nameLabel.text = nameData[indexPath.row]
//        cell.descripLabel.text = desData[indexPath.row]
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        return CGSize(width: collectionView.bounds.width, height: collectionView.bounds.height)
    }
}


extension ScrollController: UITableViewDataSource,UITableViewDelegate {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
//        tableHeight.constant = CGFloat(tablePhoto.count * 90)
       // return tablePhoto.count
        tableHeight.constant = CGFloat(20 * 98)
        return 10
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
            let cell = tableView.dequeueReusableCell(withIdentifier: "tableCell", for: indexPath) as! TableViewCell
//            cell.photoView.image = UIImage(named: tablePhoto[indexPath.row])
//            cell.pausePhoto.image = UIImage(named: pauseData[indexPath.row])
//            cell.desLabel.text = tableText[indexPath.row]
            return cell
        
       
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        
        return 90
        
    }
    
}
