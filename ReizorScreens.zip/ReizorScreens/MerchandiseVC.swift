//
//  MerchandiseVC.swift
//  Pods
//
//  Created by Coder Crew on 27/11/2023.
//

import UIKit

class MerchandiseVC: UIViewController {
    // MARK: - OUTLETS
    @IBOutlet weak var merchandiseBtn: UIButton!
    //    @IBOutlet weak var firstBtn: UIButton!
    @IBOutlet weak var BtnSongs: UIButton!
    @IBOutlet weak var BtnNTFS: UIButton!
    @IBOutlet weak var BtnItems: UIButton!
    var selectedButton: UIButton?
    
    //    MARK: - PROPERTIES{}
    var photoData = ["1","2","4","3","5","1","2","4","3","5","1","2","4","3","5","1","2","4","3","5"]

    override func viewDidLoad() {
        super.viewDidLoad()
        handleButtonSelection(selectedButton ?? UIButton())
    }
    
    func handleButtonSelection(_ sender: UIButton) {
        if let selectedButton = selectedButton, selectedButton != sender {
            selectedButton.isSelected = false
            Gradient.shared.removeGradient(btn: selectedButton)
       
            selectedButton.setTitleColor(.red, for: .normal)
        }
        
        sender.isSelected = !sender.isSelected
        selectedButton = sender
        
        if sender.isSelected {
            Gradient.shared.setUpGradientBtn(btn: sender)
           
            sender.setTitleColor(.white, for: .normal)
        } else {
            Gradient.shared.removeGradient(btn: sender)
           
            sender.setTitleColor(.red, for: .normal)
            selectedButton = nil
        }
    }
    
   
    @IBAction func onTappedMerchandise(_ sender: UIButton) {
        handleButtonSelection(sender)
    }
    @IBAction func onTappedSongs(_ sender: UIButton) {
        handleButtonSelection(sender)
    }
    
    @IBAction func onTappedItems(_ sender: UIButton) {
        handleButtonSelection(sender)
    }
    
    @IBAction func onTappedNTFS(_ sender: UIButton) {
        handleButtonSelection(sender)
    }
}
extension MerchandiseVC: UITableViewDataSource,UITableViewDelegate {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return photoData.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell  = tableView.dequeueReusableCell(withIdentifier: "tableCell", for: indexPath) as! MerchandiseTableCell
        cell.photoView.image = UIImage(named: photoData[indexPath.row])
        return cell
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let vc = self.storyboard?.instantiateViewController(withIdentifier: "ReizorEcoVC")
        self.navigationController?.pushViewController(vc!, animated: true)
    }
    
}

