//
//  CustomTable.swift
//  
//
//  Created by Coder Crew on 23/11/2023.
//

import UIKit

class CustomTable: UITableView {

    private let maxHeight = CGFloat(300)
       private let minHeight = CGFloat(100)


    override public func layoutSubviews() {
        super.layoutSubviews()
        if bounds.size != intrinsicContentSize {
            invalidateIntrinsicContentSize()
        }
    }
    
    override public var intrinsicContentSize: CGSize {
        layoutIfNeeded()
        if contentSize.height > maxHeight {
            return CGSize(width: contentSize.width, height: maxHeight)
        }
        else if contentSize.height < minHeight {
            return CGSize(width: contentSize.width, height: minHeight)
        }
        else {
            return contentSize
        }
    }


    
    
    
    override func viewWillAppear(_ animated: Bool) {
          super.viewWillAppear(animated)
          tableView.translatesAutoresizingMaskIntoConstraints = false

      }

}
