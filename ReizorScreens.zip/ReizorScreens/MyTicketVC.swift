//
//  MyTicketVC.swift
//  Pods
//
//  Created by Coder Crew on 27/11/2023.
//

import UIKit

class MyTicketVC: UIViewController {

//     MARK: - PROPERIES
    var topPhotoData = ["my","Mask0","m2","Mask4","Mask3","Mask2","Mask3","Mask2","Mask3","Mask2","Mask3","Mask2","my","Mask0","m2","Mask4","Mask3","Mask2","Mask3","Mask2","Mask3","Mask2"]
    var name = ""
    override func viewDidLoad() {
        super.viewDidLoad()

    }
    
}
extension MyTicketVC: UITableViewDataSource,UITableViewDelegate {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return topPhotoData.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "tableCell", for: indexPath) as!
        TicketTableCell
        cell.topPhotoView.image = UIImage(named: topPhotoData[indexPath.row])
        return cell
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 412
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let vc = self.storyboard?.instantiateViewController(withIdentifier: "MerchandiseVC")
        self.navigationController?.pushViewController(vc!, animated: true)
    }
}
