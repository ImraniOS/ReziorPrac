//
//  CollectionViewCell.swift
//  ReizorScreens
//
//  Created by Coder Crew on 23/11/2023.
//

import UIKit

class CollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var photoView: UIImageView!
    
    @IBOutlet weak var nameLabel: UILabel!
    
    @IBOutlet weak var descripLabel: UILabel!
    
    
}
