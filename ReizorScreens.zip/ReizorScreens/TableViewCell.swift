//
//  TableViewCell.swift
//  ReizorScreens
//
//  Created by Coder Crew on 23/11/2023.
//

import UIKit

class TableViewCell: UITableViewCell {

    @IBOutlet weak var photoView: UIImageView!
    @IBOutlet weak var pausePhoto: UIImageView!
    @IBOutlet weak var desLabel: UILabel!
   
    override func awakeFromNib() {
        super.awakeFromNib()
    }

   
}
