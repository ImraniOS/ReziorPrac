//
//  MyWalletVC.swift
//  ReizorScreens
//
//  Created by Coder Crew on 27/11/2023.
//

import UIKit

class MyWalletVC: UIViewController {
// MARK: - OUTLETS
    @IBOutlet weak var gradientView: UIView!
    @IBOutlet weak var gradientViewTwo: UIView!
//    MARK: - PROPERTIES
    var rightPhotoData = ["my","Mask0","m2","Mask4","Mask3","Mask2","Mask3","Mask2","Mask3","Mask2","Mask3","Mask2","my","Mask0","m2","Mask4","Mask3","Mask2","Mask3","Mask2","Mask3","Mask2"]
    
    override func viewDidLoad() {
        super.viewDidLoad()

        Gradient.shared.setUpGradientView(view: gradientView)
        Gradient.shared.setUpGradientView(view: gradientViewTwo)
    }
    


}


extension MyWalletVC: UITableViewDataSource,UITableViewDelegate {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return rightPhotoData.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "tableCell", for: indexPath)
        as! WalletTableCell
        cell.rightPhotoView.image = UIImage(named: rightPhotoData[indexPath.row])
        return cell
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 90
    }
    
}
