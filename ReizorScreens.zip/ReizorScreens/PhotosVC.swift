//
//  PhotosVC.swift
//  
//
//  Created by Coder Crew on 24/11/2023.
//

import UIKit

class PhotosVC: UIViewController {

    @IBOutlet weak var gradeintView: UIView!
    
    var dataPhoto = ["my","Mask0","m2","Mask4","Mask3","Mask2","Mask3","Mask2","Mask3","Mask2","Mask3","Mask2","my","Mask0","m2","Mask4","Mask3","Mask2","Mask3","Mask2","Mask3","Mask2","Mask3","Mask2","my","Mask0","m2","Mask4","Mask3","Mask2","Mask3","Mask2","Mask3","Mask2","Mask3","Mask2","my","Mask0","m2","Mask4","Mask3","Mask2","Mask3","Mask2","Mask3","Mask2","Mask3","Mask2","my","Mask0","m2","Mask4","Mask3","Mask2","Mask3","Mask2","Mask3","Mask2","Mask3","Mask2","my","Mask0","m2","Mask4","Mask3","Mask2","Mask3","Mask2","Mask3","Mask2","Mask3","Mask2","my","Mask0","m2","Mask4","Mask3","Mask2","Mask3","Mask2","Mask3","Mask2","Mask3","Mask2","my","Mask0","m2","Mask4","Mask3","Mask2","Mask3","Mask2","Mask3","Mask2","Mask3","Mask2","my","Mask0","m2","Mask4","Mask3","Mask2","Mask3","Mask2","Mask3","Mask2","Mask3","Mask2","my","Mask0","m2","Mask4","Mask3","Mask2","Mask3","Mask2","Mask3","Mask2","Mask3","Mask2","my","Mask0","m2","Mask4","Mask3","Mask2","Mask3","Mask2","Mask3","Mask2","Mask3","Mask2","my","Mask0","m2","Mask4","Mask3","Mask2","Mask3","Mask2","Mask3","Mask2","Mask3","Mask2","my","Mask0","m2","Mask4","Mask3","Mask2","Mask3","Mask2","Mask3","Mask2","Mask3","Mask2","my","Mask0","m2","Mask4","Mask3","Mask2","Mask3","Mask2","Mask3","Mask2","Mask3","Mask2","my","Mask0","m2","Mask4","Mask3","Mask2","Mask3","Mask2","Mask3","Mask2","Mask3","Mask2","my","Mask0","m2","Mask4","Mask3","Mask2","Mask3","Mask2","Mask3","Mask2","Mask3","Mask2","my","Mask0","m2","Mask4","Mask3","Mask2","Mask3","Mask2","Mask3","Mask2","Mask3","Mask2","my","Mask0","m2","Mask4","Mask3","Mask2","Mask3","Mask2","Mask3","Mask2","Mask3","Mask2","my","Mask0","m2","Mask4","Mask3","Mask2","Mask3","Mask2","Mask3","Mask2","Mask3","Mask2"]

    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        Gradient.shared.setUpGradientView(view: gradeintView)
    }
    
}

extension PhotosVC: UICollectionViewDataSource,UICollectionViewDelegateFlowLayout {
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return dataPhoto.count
    }
    
        func numberOfSections(in collectionView: UICollectionView) -> Int {
            return 3
        }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "collectionCell", for: indexPath) as! PhotoCell
        cell.photoView.image = UIImage(named: dataPhoto[indexPath.row])
        return cell
    }
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        return CGSize(width: collectionView.bounds.width*1-300, height:collectionView.bounds.height*2-950 )
    }
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumLineSpacingForSectionAt section: Int) -> CGFloat {
        return 0
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumInteritemSpacingForSectionAt section: Int) -> CGFloat {
        return 0
    }
    
    
}
