//
//  SecondViewController.swift
//  ReizorScreens
//
//  Created by Coder Crew on 23/11/2023.
//

import UIKit

class SecondViewController: UIViewController {

    @IBOutlet weak var table: UITableView!
    @IBOutlet weak var tableViewHeight: NSLayoutConstraint!
   
   
    override func viewDidLoad() {
        super.viewDidLoad()
             
        if (table.contentSize.height  < table.frame.size.height) {
                    table.isScrollEnabled = false;
                 }
                else {
                    table.isScrollEnabled = true;
                 }
        
        
        tableViewHeight.constant = table.contentSize.height

    }
}

extension SecondViewController: UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        400
        
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "tableCell", for: indexPath)
        cell.textLabel?.text = "POP"
            return cell
    }
    
    
}




//        tableViewHeight.constant = tableView.contentSize.height
//
