//
//  ViewWithDynamicScroll.swift
//  ReizorScreens
//
//  Created by Coder Crew on 24/11/2023.
//


    import Foundation
    import UIKit

    class ViewWithDynamicWidthScrollingView: UIView {
        
        convenience init() {
            self.init(frame: CGRectMake(0, 0, UIScreen.main.bounds.width, UIScreen.main.bounds.height))
        }
        
        override init(frame: CGRect) {
            super.init(frame: frame)
            self.setupHierarchy()
        }
        
        required init?(coder aDecoder: NSCoder) {
            super.init(coder: aDecoder)
            self.setupHierarchy()
        }

        private func setupHierarchy() {
            let scrollView = UIScrollView()
            scrollView.backgroundColor = UIColor.white
            addSubview(scrollView)
            scrollView.snp_makeConstraints { make in
                make.edges.equalTo(self)
            }
            
            let contentView = UIView()
            scrollView.addSubview(contentView)
            // This is the important part
            contentView.snp_makeConstraints { make in
                make.edges.equalTo(scrollView)
                make.width.equalTo(self)
            }
            
            // Make sure each view contained by the content view
            // has an height (intrisic or specified)
            
            let blackView = UIView()
            blackView.backgroundColor = UIColor.black
            contentView.addSubview(blackView)
            blackView.snp_makeConstraints { make in
                // The first child view must be pinned to the top
                // of the content view
                make.top.width.equalTo(contentView)
                make.height.equalTo(1000)
            }
            
            let redView = UIView()
            redView.backgroundColor = UIColor.redColor
            contentView.addSubview(redView)
            redView.snp_makeConstraints { make in
                make.top.equalTo(blackView.snp_bottom)
                make.width.equalTo(contentView)
                make.height.equalTo(1000)
                // The last child view must be pinned to the bottom
                // of the content view
                make.bottom.equalTo(contentView.snp_bottom)
            }
            
        }
        
    }

