//
//  PhotoCell.swift
//  ReizorScreens
//
//  Created by Coder Crew on 24/11/2023.
//

import UIKit

class PhotoCell: UICollectionViewCell {
    
    @IBOutlet weak var photoView: UIImageView!
    
}
