//
//  LinkVC.swift
//  
//
//  Created by Coder Crew on 27/11/2023.
//

import UIKit

class LinkVC: UIViewController {
// MARK: - OUTLETS{}
    @IBOutlet weak var BtnPay: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        Gradient.shared.setUpGradientBtn(btn: BtnPay)
    }
}
