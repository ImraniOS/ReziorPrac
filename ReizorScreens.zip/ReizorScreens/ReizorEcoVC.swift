//
//  ReizorEcoVC.swift
//  Pods
//
//  Created by Coder Crew on 27/11/2023.
//

import UIKit

class ReizorEcoVC: UIViewController {
    // MARK: - OUTLETS{}
    @IBOutlet weak var textfield: UITextField!
    @IBOutlet weak var textFieldTwo: UITextField!
    @IBOutlet weak var swapBtn: UIButton!
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        mainFunc()
    }
    
    
    @IBAction func onTappedSwap(_ sender: UIButton) {
        let vc = self.storyboard?.instantiateViewController(withIdentifier: "MyWalletVC")
        self.navigationController?.pushViewController(vc!, animated: true)
    }
    
}

extension ReizorEcoVC {
    func mainFunc() {
        textfield.layer.borderColor = .some(.init(srgbRed: .leastNormalMagnitude, green: .greatestFiniteMagnitude, blue: .leastNormalMagnitude, alpha: 2))
        textFieldTwo.layer.borderColor = .some(.init(srgbRed: .leastNormalMagnitude, green: .greatestFiniteMagnitude, blue: .leastNormalMagnitude, alpha: 2))
        Gradient.shared.setUpGradientBtn(btn: swapBtn)
    }
}
